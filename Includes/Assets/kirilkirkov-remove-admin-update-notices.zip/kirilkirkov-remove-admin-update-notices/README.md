# Remove Administration Update Notices

<p>Do you know the situation, when some plugin offers you to update to premium, to collect technical data and shows many annoying notices or wants you to make update? You are close these notices every now and again but they newly appears and interfere your work with WordPress. With this plugin you can easily remove them!</p>

<a href="https://github.com/Wordpress-Plugins-World/kirilkirkov-remove-admin-update-notices/blob/master/Includes/Assets/kirilkirkov-remove-admin-update-notices.zip?raw=true" download>Click to Download</a>

![alt text](https://github.com/Wordpress-Plugins-World/kirilkirkov-remove-admin-update-notices/blob/master/Includes/Assets/admin-preview.png?raw=true)
